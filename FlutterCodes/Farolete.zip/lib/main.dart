import 'package:flutter/material.dart';
// Importa o pacote necessário para controlar a lanterna.
// Lembre-se de adicionar 'torch_light: ^1.0.0' no seu arquivo pubspec.yaml!
import 'package:torch_light/torch_light.dart';

void main() {
  runApp(const FlashlightApp());
}

class FlashlightApp extends StatelessWidget {
  const FlashlightApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      // Remove o banner "Debug" que aparece no canto da tela.
      debugShowCheckedModeBanner: false,
      home: const FlashlightPage(),
    );
  }
}

// Usamos um StatefulWidget porque o estado da tela (lanterna ligada/desligada) precisa mudar.
class FlashlightPage extends StatefulWidget {
  const FlashlightPage({super.key});

  @override
  State<FlashlightPage> createState() => _FlashlightPageState();
}

class _FlashlightPageState extends State<FlashlightPage> {
  // Variável que guarda o estado atual da lanterna.
  // Começa como 'false' (desligada).
  bool _isFlashlightOn = false;

  // Função assíncrona para ligar ou desligar a lanterna.
  Future<void> _toggleFlashlight() async {
    // Primeiro, mudamos o estado da interface para dar um feedback visual imediato.
    setState(() {
      _isFlashlightOn = !_isFlashlightOn;
    });

    try {
      // Verificamos o novo estado da lanterna.
      if (_isFlashlightOn) {
        // Se for para ligar, chamamos a função do pacote.
        await TorchLight.enableTorch();
      } else {
        // Se for para desligar, chamamos a outra função.
        await TorchLight.disableTorch();
      }
    } on Exception catch (_) {
      // Bloco 'catch' para capturar erros. Isso vai acontecer no preview do FlutLab.io.
      _showErrorDialog("Erro", "Não foi possível acessar a lanterna. Este dispositivo pode não ter suporte.");
      // Se deu erro, revertemos o estado da interface para o correto.
      setState(() {
        _isFlashlightOn = false;
      });
    }
  }
  
  // Função para mostrar uma caixa de diálogo de erro.
  void _showErrorDialog(String title, String content) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: Text(title),
        content: Text(content),
        actions: [
          TextButton(
            child: const Text("OK"),
            onPressed: () {
              Navigator.of(context).pop();
            },
          ),
        ],
      ),
    );
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Lanterna Flutter'),
        backgroundColor: Colors.blueGrey[900],
        foregroundColor: Colors.white,
      ),
      // A cor do corpo da tela muda se a lanterna está ligada ou desligada.
      backgroundColor: _isFlashlightOn ? Colors.yellow[300] : Colors.grey[900],
      body: Center(
        child: Column(
          // Alinha os itens no centro da tela.
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // O ícone que representa a lanterna.
            Icon(
              _isFlashlightOn ? Icons.flashlight_on_rounded : Icons.flashlight_off_rounded,
              size: 150,
              color: _isFlashlightOn ? Colors.orangeAccent : Colors.white,
            ),
            // Espaçamento entre o ícone e o botão.
            const SizedBox(height: 50),
            // Botão principal.
            ElevatedButton(
              onPressed: _toggleFlashlight,
              style: ElevatedButton.styleFrom(
                // O texto e a cor do botão também mudam.
                backgroundColor: _isFlashlightOn ? Colors.redAccent : Colors.green,
                padding: const EdgeInsets.symmetric(horizontal: 50, vertical: 20),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(30),
                ),
              ),
              child: Text(
                _isFlashlightOn ? 'DESLIGAR' : 'LIGAR',
                style: const TextStyle(
                  fontSize: 22,
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ],
        ),
      ),
    );
    }
}